# Genetic Algorithms
To use my genetic algorithm, you can run the following command:
```bash
python genetic.py
```
This will run the algorithm with a generation of 50, a population size of 500, and a mutation population .3. To run the algorithm with custom values, run the following command:
```bash
python genetic.py -g [generations] -p [population_size] -m [mutation probability]
```
