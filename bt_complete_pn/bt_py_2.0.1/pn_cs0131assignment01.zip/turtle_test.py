import turtle
import time

turtle.forward(100)
time.sleep(1)
turtle.left(120)
time.sleep(1)
turtle.forward(100)
time.sleep(1)
